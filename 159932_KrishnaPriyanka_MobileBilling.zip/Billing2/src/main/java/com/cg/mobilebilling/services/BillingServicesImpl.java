package com.cg.mobilebilling.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostPaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private BillingDAOServices billingDAOServices;
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private PlanDAO planDAO;
	@Autowired
	private PostPaidAccountDAO postPaidAccountDAO;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		List<Plan> plan=planDAO.findAll();
		if(plan==null)throw new BillingServicesDownException("Plan Details do not exist");
		return plan;
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		savePlanDetails();
		customerDAO.save(customer);
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		Plan plan=planDAO.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("Plan Details Not Found for"+planID));
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postPaidAccountDAO.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException, BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		PostpaidAccount postpaid=postPaidAccountDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaid==null)throw new PostpaidAccountNotFoundException("Post paid not found for "+mobileNo);	
		Bill bill1=billingDAOServices.getMobileBillDetails(postpaid ,billMonth);
		if(bill1==null) {
		
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, postpaid);
		if(noOfLocalSMS>postpaid.getPlan().getFreeLocalSMS())
			bill.setLocalSMSAmount((noOfLocalSMS-postpaid.getPlan().getFreeLocalSMS())*postpaid.getPlan().getLocalSMSRate());
		else
			bill.setLocalSMSAmount(0);
		if(noOfStdSMS>postpaid.getPlan().getFreeStdSMS())
		bill.setStdSMSAmount((noOfStdSMS-postpaid.getPlan().getFreeStdSMS())*postpaid.getPlan().getStdSMSRate());
		else
			bill.setStdSMSAmount(0);
		if(noOfLocalCalls>postpaid.getPlan().getFreeLocalCalls())
		bill.setLocalCallAmount((noOfLocalCalls-postpaid.getPlan().getFreeLocalCalls())*postpaid.getPlan().getLocalCallRate());
		else
			bill.setLocalCallAmount(0);
		if(noOfStdCalls>postpaid.getPlan().getFreeStdCalls())
		bill.setStdCallAmount((noOfStdCalls-postpaid.getPlan().getFreeStdCalls())*postpaid.getPlan().getStdCallRate());
		else
			bill.setStdCallAmount(0);
		if(internetDataUsageUnits>postpaid.getPlan().getFreeInternetDataUsageUnits())
		bill.setInternetDataUsageAmount((internetDataUsageUnits-postpaid.getPlan().getFreeInternetDataUsageUnits())*postpaid.getPlan().getInternetDataUsageRate());
		else
			bill.setInternetDataUsageAmount(0);
		float intialamount=bill.getLocalSMSAmount()+bill.getLocalCallAmount()+bill.getStdSMSAmount()+bill.getStdCallAmount()+bill.getInternetDataUsageAmount()+postpaid.getPlan().getMonthlyRental();
		bill.setcGst((intialamount*2)/100);
		bill.setsGst((intialamount*2)/100);
		bill.setTotalBillAmount(intialamount+bill.getcGst()+bill.getsGst());
		billingDAOServices.save(bill);
		return bill;
		}
		else
			throw new BillingServicesDownException("Bill Already exists for this month");
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> customers=customerDAO.findAll();
		if(customers==null)throw new BillingServicesDownException("No customer details");
		return customers;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		PostpaidAccount postpaidAccount=postPaidAccountDAO.getPostPaidAccountDetails(customer, mobileNo);
		if(postpaidAccount==null)throw new PostpaidAccountNotFoundException("Post paid not found for "+mobileNo);	
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException,PostpaidAccountNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		List<PostpaidAccount> postpaid=new ArrayList<>();
		postpaid=postPaidAccountDAO.getCustomerAllPostpaidAccountsDetails(customer);
		if(postpaid==null)throw new PostpaidAccountNotFoundException("No post paid accounts");
		return postpaid;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		PostpaidAccount postpaid=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaid==null)throw new PostpaidAccountNotFoundException("Post paid details not found for"+mobileNo);
		Bill bill=billingDAOServices.getMobileBillDetails(postpaid ,billMonth);
		if(bill==null)
			throw new InvalidBillMonthException("Enter a valid bill month");
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaidAccount==null)throw new PostpaidAccountNotFoundException("Post paid details not found for"+mobileNo);
		List<Bill> bill=new ArrayList<>();
		 bill=postPaidAccountDAO.getCustomerPostPaidAccountAllBillDetails(customer, mobileNo);
		 if(bill==null) throw new BillingServicesDownException("Bill Details Not found ");
		return bill;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaidAccount==null)throw new PostpaidAccountNotFoundException("Post paid details not found for"+mobileNo);
		Plan plan=planDAO.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("Plan Details Not Found for"+planID));
		postpaidAccount=new PostpaidAccount(mobileNo, plan, customer);
		postPaidAccountDAO.save(postpaidAccount);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details Not Found With CustomerID="+customerID));
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		if(postpaidAccount==null)throw new PostpaidAccountNotFoundException("Post paid details not found for"+mobileNo);
		billingDAOServices.deleteAllBills(postpaidAccount);
		postPaidAccountDAO.closeCustomerPostPaidAccount(customer, mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		ArrayList<PostpaidAccount>postpaidAccounts=(ArrayList<PostpaidAccount>) getCustomerAllPostpaidAccountsDetails(customerID);
		for(PostpaidAccount postpaidAccount:postpaidAccounts) {
			closeCustomerPostPaidAccount(customerID, postpaidAccount.getMobileNo());			
		}
		customerDAO.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer Details for customerID "+customerID+" not found"));
		Plan plan=postPaidAccountDAO.getCustomerPostPaidAccountPlanDetails(customer, mobileNo);
		if(plan==null)throw new PostpaidAccountNotFoundException("post paid account not found for "+mobileNo);
		return plan;
	}

	@Override
	public void savePlanDetails() {
		Plan plan1=new Plan(1001, 50, 100, 100, 100, 100, 50, 2, 2, 2, 2, 50, "mumbai", "nestham");
		planDAO.save(plan1);
		Plan plan2=new Plan(1002, 40, 150, 160, 260, 300, 40, 2, 1, 2, 1, 20, "pune", "abc");
		planDAO.save(plan2);
		Plan plan3=new Plan(1003, 50, 200, 180, 210, 200, 20, 1, 2, 2, 1, 50, "goa", "xyz");
		planDAO.save(plan3);
		
	}
}