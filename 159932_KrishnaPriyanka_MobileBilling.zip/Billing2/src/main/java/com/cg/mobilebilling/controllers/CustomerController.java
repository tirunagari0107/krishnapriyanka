package com.cg.mobilebilling.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class CustomerController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/registerCustomer1")
	public ModelAndView acceptCustomerDetails(@Valid@ModelAttribute Customer customer,BindingResult result) throws BillingServicesDownException {
		if(result.hasErrors())
			return new ModelAndView("registerCustomerPage");
		int customerId=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessfull", "customerId", customerId);
	}
	@RequestMapping("/openPostPaid1")
	public ModelAndView openPostPaidAccount(@RequestParam("customerId")int customerId,@RequestParam("planId")int planId) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException{
		long mobileNo=billingServices.openPostpaidMobileAccount(customerId, planId);
		return new ModelAndView("openPostPaidSuccesfull", "mobileNo", mobileNo);
	}
	@RequestMapping("/getCustomer1")
	public ModelAndView getCustomerDetails(@RequestParam("customerId")int customerId) throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=billingServices.getCustomerDetails(customerId);
		return new ModelAndView("getCustomerDetails", "customer", customer);
	}
	@RequestMapping("/getPostPaid1")
	public ModelAndView getPostPaidDetails(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerId, mobileNo);
		return new ModelAndView("getPostPaidDetails", "postpaidAccount", postpaidAccount);
	}
	@RequestMapping("/getAllCustomers")
	public ModelAndView getAllCustomers() throws BillingServicesDownException {
	     List<Customer> customers=billingServices.getAllCustomerDetails();
		return new ModelAndView("getAllCustomersPage", "customers", customers);
	}
	@RequestMapping("/getAllPostPaid1")
	public ModelAndView getAllPostPaid(@RequestParam("customerId")int customerId) throws CustomerDetailsNotFoundException, BillingServicesDownException,PostpaidAccountNotFoundException{
	     List<PostpaidAccount> postpaidAccounts=billingServices.getCustomerAllPostpaidAccountsDetails(customerId);
		return new ModelAndView("getAllPostPaid", "postpaidAccounts", postpaidAccounts);
	}
	@RequestMapping("/getPlan1")
	public ModelAndView getPlanDetails(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		Plan plan=billingServices.getCustomerPostPaidAccountPlanDetails(customerId, mobileNo);
		return new ModelAndView("getPlanDetails", "plan", plan);
	}
	@RequestMapping("/deleteCustomer1")
	public ModelAndView deleteCustomer1(@RequestParam("customerId")int customerId) throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException{
	     billingServices.deleteCustomer(customerId);
		return new ModelAndView("deleteCustomerDetails");
	}
	@RequestMapping("/closePostPaid1")
	public ModelAndView closePostPaid1(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		billingServices.closeCustomerPostPaidAccount(customerId, mobileNo);
		return new ModelAndView("closePostPaidDetails");
	}
	@RequestMapping("/changePlan1")
	public ModelAndView changePlan1(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo,@RequestParam("planId")int planId) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		billingServices.changePlan(customerId, mobileNo, planId);
		return new ModelAndView("changePlanDetails","mobileNo",mobileNo);
	}
	@RequestMapping("/getAllBill1")
	public ModelAndView getAllBill1(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo) throws BillDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		List<Bill>bills=billingServices.getCustomerPostPaidAccountAllBillDetails(customerId, mobileNo);
		return new ModelAndView("getAllBillDetails","bills",bills);
	}
	@RequestMapping("/getMobileBill1")
	public ModelAndView getMobileBill1(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException {
		Bill bill=billingServices.getMobileBillDetails(customerId, mobileNo, billMonth);
		return new ModelAndView("getMobileBillDetails","bill",bill);
	}
	@RequestMapping("/generateBill1")
	public ModelAndView generateBill1(@RequestParam("customerId")int customerId,@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth,@RequestParam("noOfLocalSMS")int noOfLocalSMS,@RequestParam("noOfStdSMS")int noOfStdSMS,
			@RequestParam("noOfLocalCalls")int noOfLocalCalls,@RequestParam("noOfStdCalls")int noOfStdCalls,@RequestParam("internetDataUsageUnits")int internetDataUsageUnits) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillingServicesDownException, PlanDetailsNotFoundException, BillDetailsNotFoundException {
		Bill bill=billingServices.generateMonthlyMobileBill(customerId, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
		return new ModelAndView("generateBillDetails","bill",bill);
	}
}
