package com.cg.mobilebilling.boot;

import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import static org.assertj.core.api.Assertions.assertThat;
import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAO;
import com.cg.mobilebilling.daoservices.PlanDAO;
import com.cg.mobilebilling.daoservices.PostPaidAccountDAO;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BillingApplicationTests {

	@MockBean
	private  CustomerDAO customerDAO;
	@MockBean
	private PlanDAO planDAO;
	@MockBean
	private BillingDAOServices billingDAO;
	@MockBean
	private PostPaidAccountDAO postpaidDAO;
	@Autowired
	private BillingServices billingServices;
	private Bill bill1;
	private Customer customer1,customer2;
	private PostpaidAccount postpaidAccount1,postpaidAccount2,postpaidAccount3;
	private ArrayList<Customer> customerList = new ArrayList<>();
	private ArrayList<PostpaidAccount> postPaidAccountList = new ArrayList<>();
	private Plan plan1 ;
	@Before
	public void setUpData() {
		customer1 = new Customer(111,"Priyanka", "Tirunagari", "tirunagari@gmail.com", "01/07/1997", new Address(405750, "pune", "Maharastra"));
		customer2= new Customer(222,"Vysali", "Tirunagari", "vysali@gmail.com", "21/07/1998", new Address(405750, "pune", "Maharastra"));
		bill1= new Bill(11,100, 100, 100, 100, 200, "January", 555.5f, 2.5f, 3.5f, 0.0f, 0.0f, 0.0f, 25.25f, 25.25f,postpaidAccount3);
		postpaidAccount1=new PostpaidAccount(9550537835l, plan1, customer1);
		postpaidAccount2 = new PostpaidAccount(9550537838l, plan1, customer1);
		postpaidAccount3 = new PostpaidAccount(9550537837l, plan1, customer2);
		plan1 = new Plan(1,499,100,100,50,50,1000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan101");
		postPaidAccountList.add(postpaidAccount1);
		postPaidAccountList.add(postpaidAccount2);
		customerList.add(customer1);
		customerList.add(customer2);
		
	}
	
	@Test
	public void acceptCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.save(Mockito.any(Customer.class))).thenReturn(customer1);
		int customerId=billingServices.acceptCustomerDetails(customer1);
		assertThat(111).isEqualTo(customerId);	
	}
	
	@Test
	public void getAllCustomerDetailsTest() throws BillingServicesDownException {
		Mockito.when(customerDAO.findAll()).thenReturn(customerList);
		assertThat(billingServices.getAllCustomerDetails()).isEqualTo(customerList);	
	}
	
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomerOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.openPostpaidMobileAccount(110,111);
		Mockito.verify(customerDAO.findById(Mockito.anyInt()));
	}
	
	@Test
	public void getCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		assertThat(billingServices.getCustomerDetails(111)).isEqualTo(customer1);

	}
	
	@Test(expected =PlanDetailsNotFoundException.class)
	public void invalidPlanOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.openPostpaidMobileAccount(111,11);
	}
	
	@Test
	public void openPostpaidMobileAccountTest() throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(planDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(plan1));
		Mockito.when(postpaidDAO.save(Mockito.any(PostpaidAccount.class))).thenReturn(postpaidAccount1);
		assertThat(billingServices.openPostpaidMobileAccount(111, 1)).isEqualTo(9550537835l);
	}
	
	@Test
	public void getPostPaidAccountDetailsTest() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer2));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class), Mockito.anyLong())).thenReturn(postpaidAccount3);
		assertThat(billingServices.getPostPaidAccountDetails(222, 9550537837l)).isEqualTo(postpaidAccount3);
	}
	
	@Test
	public void getCustomerAllPostpaidAccountsDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getCustomerAllPostpaidAccountsDetails(Mockito.any(Customer.class))).thenReturn(postPaidAccountList);
		assertThat(billingServices.getCustomerAllPostpaidAccountsDetails(111)).isEqualTo(postPaidAccountList);
	}
	
	@Test
	public void generateMonthlyMobileBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(planDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(plan1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class), Mockito.anyLong())).thenReturn(postpaidAccount1);
		Mockito.when(billingDAO.getMobileBillDetails(Mockito.any(PostpaidAccount.class),Mockito.any(String.class))).thenReturn(null);
		Mockito.when(billingDAO.save(Mockito.any(Bill.class))).thenReturn(bill1);
		Bill bill=billingServices.generateMonthlyMobileBill(111, 9550537838l, "January", 100, 100, 100, 100, 200);
		assertThat(bill.getTotalBillAmount()).isEqualTo(555.5f);
	}

	@Test
	public void getMobileBillDetailsTest() throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class), Mockito.anyLong())).thenReturn(postpaidAccount1);
		Mockito.when(billingDAO.getMobileBillDetails(Mockito.any(PostpaidAccount.class),Mockito.any(String.class))).thenReturn(bill1);
		Bill bill=billingServices.getMobileBillDetails(111,9550537838l, "January");
		assertThat(bill.getTotalBillAmount()).isEqualTo(555.5f);
	}
}
