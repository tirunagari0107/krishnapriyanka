package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.payroll.pagebeans.RegistrationPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculateNetSalaryStepDefinition {
	private WebDriver driver;
	private RegistrationPage registrationPage;

	@Given("^Associate is on 'calculateNetSalaryPage'$")
	public void associate_is_on_calculateNetSalaryPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("localhost:2024/calculateSalary");	
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	
	}
	@When("^Associate enters valid 'associateId'$")
	public void associate_enters_valid_associateId() throws Throwable {
		registrationPage.setAssociateId("1");
		registrationPage.Submit();
	}

	@Then("^Associate is directed to 'displayNetSalaryPage'$")
	public void associate_is_directed_to_displayNetSalaryPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Salary Calculated";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
