package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.RegistrationPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	private WebDriver driver;
	private RegistrationPage registrationPage;
	@Given("^Associate is on registration Page$")
	public void associate_is_on_registration_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("localhost:2024/registration");	
		registrationPage=PageFactory.initElements(driver, RegistrationPage.class);
	}

	@When("^Associate enter his correct credentials$")
	public void associate_enter_his_correct_credentials() throws Throwable {
		registrationPage.setFirstName("Tirunagari");
		registrationPage.setLastName("priyanka");
		registrationPage.setDepartment("erty");
		registrationPage.setDesignation("srg");
		registrationPage.setPancard("efpp1234");
		registrationPage.setEmailId("tirun@gmail.com");
		registrationPage.setYearlyInvestmentUnder8oC("2000");
		registrationPage.setAccountNumber("23456");
		registrationPage.setBankName("wery");
		registrationPage.setIfscCode("erty2345");
		registrationPage.setEpf("2000");
		registrationPage.setBasicSalary("15000");
		registrationPage.setCompanyPf("2000");
		registrationPage.Submit();

	}

	@Then("^Associate is redirected to registration success page$")
	public void associate_is_redirected_to_registration_success_page() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}


}
