package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllAssociateDetailsStepDefinition {
	private WebDriver driver;
	@Given("^Admin is on the HomePage of 'Capgemini Payroll System'$")
	public void admin_is_on_the_HomePage_of_Capgemini_Payroll_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("localhost:2024");	
	}

	@When("^Admin clicks on 'View All Associate Details' button$")
	public void admin_clicks_on_View_All_Associate_Details_button() throws Throwable {
		By by=By.xpath("/html/body/table/tbody/tr[4]/td/a");
		driver.findElement(by).click();
	}

	@Then("^Admin is directed to 'viewAllAssociateDetailsPage'$")
	public void admin_is_directed_to_viewAllAssociateDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="All Associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

}
