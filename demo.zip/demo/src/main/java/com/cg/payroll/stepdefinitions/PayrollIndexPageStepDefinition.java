package com.cg.payroll.stepdefinitions;

import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PayrollIndexPageStepDefinition {
	
	private WebDriver driver;
	@Given("^Associate is on index Page$")
	public void associate_is_on_index_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("localhost:2024");
	   
	}

	@When("^Associate click on registration link$")
	public void associate_click_on_registration_link() throws Throwable {
		By by1=By.xpath("/html/body/table/tbody/tr[1]/td/a");
		driver.findElement(by1).click();
	}

	@Then("^Associate is redirected to registration page$")
	public void associate_is_redirected_to_registration_page() throws Throwable {
	  String actualTitle=driver.getTitle();
	  String expectedTitle="Registration";
	  Assert.assertEquals(expectedTitle, actualTitle);
	  driver.close();
	}
	

}
