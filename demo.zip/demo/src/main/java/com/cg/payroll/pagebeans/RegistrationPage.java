package com.cg.payroll.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegistrationPage {
	
	@FindBy(how=How.ID,id="associateId")
	private WebElement associateId;
	@FindBy(how=How.ID,id="firstName")
	private WebElement firstName;
	@FindBy(how=How.ID,id="lastName")
	private WebElement lastName;
	@FindBy(how=How.ID,id="department")
	private WebElement department;
	@FindBy(how=How.ID,id="designation")
	private WebElement designation;
	@FindBy(how=How.ID,id="pancard")
	private WebElement pancard;
	@FindBy(how=How.ID,id="emailId")
	private WebElement emailId;
	@FindBy(how=How.ID,id="yearlyInvestmentUnder8oC")
	private WebElement yearlyInvestmentUnder8oC;
	@FindBy(how=How.ID,id="accountNumber")
	private WebElement accountNumber;
	@FindBy(how=How.ID,id="bankName")
	private WebElement bankName;
	@FindBy(how=How.ID,id="ifscCode")
	private WebElement ifscCode;
	@FindBy(how=How.ID,id="epf")
	private WebElement epf;
	@FindBy(how=How.ID,id="basicSalary")
	private WebElement basicSalary;
	@FindBy(how=How.ID,id="companyPf")
	private WebElement companyPf;
	@FindBy(how=How.ID,id="submit")
	private WebElement submit;
	public RegistrationPage() {}
	
	
	public String getAssociateId() {
		return associateId.getAttribute("value");
	}

	public void setAssociateId(String associateId) {
		this.associateId.sendKeys(associateId);
	}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getDepartment() {
		return department.getAttribute("value");
	}
	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}
	public String getDesignation() {
		return designation.getAttribute("value");
	}
	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}
	public String getPancard() {
		return pancard.getAttribute("value");
	}
	public void setPancard(String pancard) {
		this.pancard.sendKeys(pancard);
	}
	public String getEmailId() {
		return emailId.getAttribute("value");
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public String getYearlyInvestmentUnder8oC() {
		return yearlyInvestmentUnder8oC.getAttribute("value");
	}
	public void setYearlyInvestmentUnder8oC(String yearlyInvestmentUnder8oC) {
		this.yearlyInvestmentUnder8oC.sendKeys(yearlyInvestmentUnder8oC);
	}
	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber.sendKeys(accountNumber);
	}
	public String getBankName() {
		return bankName.getAttribute("value");
	}
	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);
	}
	public String getIfscCode() {
		return ifscCode.getAttribute("value");
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode.sendKeys(ifscCode);
	}
	public String getEpf() {
		return epf.getAttribute("value");
	}
	public void setEpf(String epf) {
		this.epf.sendKeys(epf);
	}
	public String getBasicSalary() {
		return basicSalary.getAttribute("value");
	}
	public void setBasicSalary(String basicSalary) {
		this.basicSalary.sendKeys(basicSalary);
	}
	public String getCompanyPf() {
		return companyPf.getAttribute("value");
	}
	public void setCompanyPf(String companyPf) {
		this.companyPf.sendKeys(companyPf);
	}
	
	public void Submit() {
		this.submit.click();
	}
}
